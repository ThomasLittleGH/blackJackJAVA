/*
 * Programa dedicado a entretener al usuario con el juego blackJack
 */
package blackjak;

import java.awt.Color;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import static javax.swing.WindowConstants.EXIT_ON_CLOSE;

/**
 *
 * @author Thomas Litle
 */
public class BlackJak extends JFrame implements ActionListener {

    // Definicion de variables
    private JButton btnJugar, btnOtra, btnMeQuedo;
    private JPanel panJugar, panUsuario, panComputador;
    private JTextField txaPuntosUser, txaPuntosPC;
    private JLabel lblCarta1, lblCarta2, lblCarta3, lblCarta4, lblCarta5, lblCarta6, lblCarta7, lblCarta8, lblCarta9, lblCarta10;
    ArrayList<Integer> array;
    imagenesCartas objImagenes;
    int valorUser, valorPC, aux, cartas, cartas2;

    public BlackJak() {
        initComponentes();
        initJugar();
    }

    private void initJugar() {
        // Intancio el layout a utilizar en mi programa
        BoxLayout bl = new BoxLayout(panJugar, BoxLayout.Y_AXIS);
        // Agrego los contenedores al formulario y estableco sus propiedades
        this.add(panJugar);
        panJugar.setLayout(bl);
        panJugar.add(btnJugar);
        btnJugar.addActionListener(this);
        panJugar.add(panUsuario);
        panUsuario.setBackground(Color.LIGHT_GRAY);
        panUsuario.setBorder(BorderFactory.createTitledBorder("Usuario"));
        panUsuario.add(btnOtra);
        panUsuario.add(btnMeQuedo);
        panUsuario.add(txaPuntosUser);
        txaPuntosUser.setEditable(false);
        // llamo a un metodo que establece los valores iniciales de algunas variables y le asigna la imagen de las tarjetas al label
        reset();
        
        // Agrego los action listener a los botones
        btnOtra.addActionListener(this);
        btnMeQuedo.addActionListener(this);
        // Le agrego las cartas con imagen al formulario
        panUsuario.add(lblCarta1);
        panUsuario.add(lblCarta2);
        panUsuario.add(lblCarta3);
        panUsuario.add(lblCarta4);
        panUsuario.add(lblCarta5);
        // repito el paso anterior pero para el panel del computador
        panJugar.add(panComputador);
        panComputador.setBackground(Color.DARK_GRAY);
        panComputador.setBorder(BorderFactory.createTitledBorder("Computador"));
        panComputador.add(lblCarta6);
        panComputador.add(lblCarta7);
        panComputador.add(lblCarta8);
        panComputador.add(lblCarta9);
        panComputador.add(lblCarta10);
        panComputador.add(txaPuntosPC);

    }

    private void initComponentes() {
        // Instanciaciones
        panUsuario = new JPanel();
        panComputador = new JPanel();
        panJugar = new JPanel();
        btnJugar = new JButton("Jugar");
        btnOtra = new JButton("Otra");
        btnMeQuedo = new JButton("Me Quedo");
        txaPuntosUser = new JTextField("0");
        txaPuntosPC = new JTextField("0");
        lblCarta1 = new JLabel(" ");
        lblCarta2 = new JLabel(" ");
        lblCarta3 = new JLabel(" ");
        lblCarta4 = new JLabel(" ");
        lblCarta5 = new JLabel(" ");
        lblCarta6 = new JLabel(" ");
        lblCarta7 = new JLabel(" ");
        lblCarta8 = new JLabel(" ");
        lblCarta9 = new JLabel(" ");
        lblCarta10 = new JLabel(" ");
        array = new ArrayList<Integer>();
    }

    public static void main(String[] args) {
        // Inicio el programa y muestro el formulario
        BlackJak ventana = new BlackJak();
        ventana.setVisible(true);
        ventana.setSize(1200, 600);
        ventana.setLocationRelativeTo(null);
        ventana.setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        objImagenes = new imagenesCartas();
        // Si el usuario apreta el boton jugar entonces le asigno 2 cartas
        if (e.getSource() == btnJugar) {
            aux = objImagenes.generarNumero();
            lblCarta1.setIcon(objImagenes.carta(aux, array));
            array.add(aux);
            valorUser = aux;
            aux = objImagenes.generarNumero();
            lblCarta2.setIcon(objImagenes.carta(aux, array));
            array.add(aux);
            valorUser = valorUser + aux;
            txaPuntosUser.setText(Integer.toString(valorUser));
        }
        // Si el usuario apreta el boton otra entonces le asigno otra carta dependiendo del numero de carta que YA tengo
        if (e.getSource() == btnOtra) {
            aux = objImagenes.generarNumero();
            switch (cartas) {
                case 3:
                    lblCarta3.setIcon(objImagenes.carta(aux, array));
                    array.add(aux);
                    valorUser = valorUser + aux;
                    break;
                case 4:
                    lblCarta4.setIcon(objImagenes.carta(aux, array));
                    array.add(aux);
                    valorUser = valorUser + aux;
                    break;
                case 5:
                    lblCarta5.setIcon(objImagenes.carta(aux, array));
                    array.add(aux);
                    valorUser = valorUser + aux;
                    break;
                default:
                    System.out.println(" ");
                    break;

            }
            cartas++;
            // Refresco el valor de los puntos del usuario
            txaPuntosUser.setText("" + valorUser);
        }
        // Si el usuario apreta este boton, el computador revela sus cartas y saca mas dependiendo si tiene menos de 16 o no
        if (e.getSource() == btnMeQuedo) {
            while (valorPC < 16) {
                aux = objImagenes.generarNumero();
                switch (cartas2) {
                    case 6:
                        lblCarta6.setIcon(objImagenes.carta(aux, array));
                        array.add(aux);
                        valorPC = valorPC + aux;
                        break;
                    case 7:
                        lblCarta7.setIcon(objImagenes.carta(aux, array));
                        array.add(aux);
                        valorPC = valorPC + aux;
                        break;
                    case 8:
                        lblCarta8.setIcon(objImagenes.carta(aux, array));
                        array.add(aux);
                        valorPC = valorPC + aux;
                        break;
                    case 9:
                        lblCarta9.setIcon(objImagenes.carta(aux, array));
                        array.add(aux);
                        valorPC = valorPC + aux;
                        break;
                    case 10:
                        lblCarta10.setIcon(objImagenes.carta(aux, array));
                        array.add(aux);
                        valorPC = valorPC + aux;
                        break;
                    default:
                        System.out.println(" ");
                        break;

                }
                cartas2++;
            }
            // Reviso si alguno de las partes ha ganado y reestablezco los valores
            txaPuntosPC.setText("" + valorPC);
            if ((valorPC >= valorUser) && (valorPC < 21)) {
                JOptionPane.showMessageDialog(null, "Ha perdido");
                reset();
            }
            else {
                JOptionPane.showMessageDialog(null, "Ha ganado");
                reset();
            }

        }
        // Si el jugador se pasa de los 21 puntos entonces pierde, le aviso y reinicio los datos
        if (valorUser > 21) {
            JOptionPane.showMessageDialog(null, "Ha perdido");
            reset();
        }
    }

    private void reset() throws HeadlessException {
        objImagenes = new imagenesCartas();
        cartas = 3;
        cartas2 = 6;
        aux = 0;
        valorUser = 0;
        valorPC = 0;
        array.clear();
        lblCarta1.setIcon(objImagenes.carta(-1, array));
        lblCarta2.setIcon(objImagenes.carta(-1, array));
        lblCarta3.setIcon(objImagenes.carta(-1, array));
        lblCarta4.setIcon(objImagenes.carta(-1, array));
        lblCarta5.setIcon(objImagenes.carta(-1, array));
        lblCarta6.setIcon(objImagenes.carta(-1, array));
        lblCarta7.setIcon(objImagenes.carta(-1, array));
        lblCarta8.setIcon(objImagenes.carta(-1, array));
        lblCarta9.setIcon(objImagenes.carta(-1, array));
        lblCarta10.setIcon(objImagenes.carta(-1, array));
        txaPuntosPC.setText("" + valorPC);
        txaPuntosUser.setText("" + valorUser);
    }
}
