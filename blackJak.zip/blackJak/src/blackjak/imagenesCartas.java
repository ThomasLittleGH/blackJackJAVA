/*
 * Clase que recupera la imagen del numero del dado
 */
package blackjak;

import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;

/**
 *
 * @author Thomas Little
 */
public class imagenesCartas {

    public ImageIcon icono;
    // Genera un numero aleatoreo
    public int generarNumero() {
        Random numeroAleatoreo = new Random();
        return numeroAleatoreo.nextInt(13) + 1;
    }

    public ImageIcon carta(int dado, ArrayList<Integer> array) {
        // Dependiendo del numero aleatoreo que ya saque y si ya he sacado otra carta con el mismo valor el programa decide que carta y pinto sacar
        switch (dado) {
            case 1:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/1d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/1c.png"));
                }
                break;

            case 2:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/2d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/2c.png"));
                }
                break;

            case 3:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/3d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/3c.png"));
                }

                break;

            case 4:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/4d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/4c.png"));
                }

                break;

            case 5:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/5d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/5c.png"));
                }
                break;

            case 6:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/6d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/6c.png"));
                }
                break;

            case 7:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/7d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/7c.png"));
                }
                break;

            case 8:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/8d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/8c.png"));
                }
                break;

            case 9:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/9d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/9c.png"));
                }
                break;

            case 10:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/10d.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/10c.png"));
                }
                break;

            case 11:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/jd.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/jc.png"));
                }
                break;

            case 12:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/qd.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/qc.png"));
                }
                break;

            case 13:
                if (array.contains(dado)) {
                    icono = new ImageIcon(getClass().getResource("/imagenes/kd.png"));
                }
                else {
                    icono = new ImageIcon(getClass().getResource("/imagenes/kc.png"));
                }
                break;
            case -1:
                icono = new ImageIcon(getClass().getResource("/imagenes/clear.png"));
                break;

        }
        return icono;
    }

}
